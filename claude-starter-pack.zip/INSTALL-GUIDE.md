# Harry's Claude Code Setup — Installation Guide

This guide gets you the same AI setup Harry uses: Claude Code running inside VS Code, upgraded with persistent memory, structured working methods, a knowledge vault, and the ability to ask other AI models for second opinions.

You do **four small manual installs**, drop one folder into place, and then paste a single prompt into Claude — and Claude installs and configures everything else itself. Total time: roughly 45 minutes, most of which is Claude working while you watch.

**You will need:** a Windows PC, a Claude subscription (Pro works; **Max is recommended** because this setup runs Claude's most capable model, Opus, by default), and the two files Harry sent you: `claude-starter-pack.zip` and `BOOTSTRAP-PROMPT.txt`.

---

## What you're actually getting

A plain-English tour of each piece, so nothing feels like a mystery box:

| Component | What it does for you |
|---|---|
| **Claude Code (in VS Code)** | The AI assistant itself, living in a panel of your editor. It can read and write files, run programs, browse the web, and carry out whole projects — not just chat. |
| **Superpowers** | A library of "working methods" for Claude — structured routines for brainstorming, planning, debugging, and checking its own work. It makes Claude behave like a disciplined colleague instead of an eager intern. |
| **claude-mem (memory)** | Normally Claude forgets everything when you close a session. This gives it a permanent memory: every session's key events are saved and automatically recalled later, so you can ask "how did we solve this last month?" |
| **Obsidian vault** | A folder of linked notes where Claude records important decisions and project knowledge. If you install the free Obsidian app, you can see it as a visual knowledge graph — but the notes work even without it. |
| **claude-council** | Lets Claude ask *other* AI models (Google's Gemini, Moonshot's Kimi) for second opinions with the `/ask` command. Great for hard decisions and stubborn problems. Needs free API keys — covered in Step 5. |
| **token-optimizer** | Housekeeping that runs in the background and stops Claude wasting its limited "attention span" (context), plus automatic checkpoints so a crashed session can be recovered. |
| **graphify** | Builds a map of any codebase or folder so Claude understands its structure without reading every file. Optional but cheap to have. |
| **60+ skills** | Ready-made commands like `/qa` (test a website), `/investigate` (systematic debugging), `/make-pdf` (turn notes into a polished PDF), `/ship` (package up and publish work). |
| **Opus by default, no permission prompts** | Claude uses its most capable model automatically, and doesn't stop to ask "may I?" before every action. More on the safety trade-off in Step 3. |

---

## Step 1 — Install the apps (the manual bit)

Install these three (plus one optional), in order. Accept the default options in every installer.

1. **Visual Studio Code** — the editor everything lives in.
   Download: https://code.visualstudio.com

2. **Git for Windows** — needed because parts of the setup run through a mini command-line tool it includes ("Git Bash"). You'll never use it directly.
   Download: https://git-scm.com/download/win

3. **Claude Code extension for VS Code** — open VS Code, click the Extensions icon in the left sidebar (four squares), search for **"Claude Code"** (by Anthropic), and click Install. Then click the Claude icon that appears in the sidebar and **sign in** with your Claude account.

4. *(Optional)* **Obsidian** — only needed if you want the pretty knowledge-graph view of your vault.
   Download: https://obsidian.md

Once you're signed in to Claude Code, **open a chat and say hello, then close VS Code.** That first launch creates the folder we need for Step 2.

---

## Step 2 — Drop in the starter pack

The starter pack is a sanitised copy of Harry's configuration — his settings, skills, and working methods, with all his personal data and account keys removed.

1. Open **File Explorer**.
2. Click into the address bar at the top, type `%USERPROFILE%` and press Enter. This takes you to your user folder (e.g. `C:\Users\yourname`).
3. Find the folder called **`.claude`** (it was created when you launched Claude Code). If you can't see it, click **View → Show → Hidden items**.
4. Open `claude-starter-pack.zip`, select **everything inside it**, and copy it into the `.claude` folder. If Windows asks about replacing files (like `settings.json`), choose **Replace**.

That's it — don't edit anything. The next step's prompt makes Claude adapt the files to your machine automatically.

---

## Step 3 — Understand the two "power settings" you just installed

The settings file you copied switches on two things worth understanding:

**Opus by default.** Every session uses Claude's most capable model. It's the best experience, but it uses your subscription's allowance faster — this is why Max is recommended.

**Bypass permissions.** Out of the box, Claude asks for approval before almost every action ("May I run this? May I edit this file?"), which gets tedious fast. This setting lets it just work.

> ⚠️ **The honest trade-off:** with permissions bypassed, Claude can create, modify, and delete files and run programs on your computer without asking first. In practice it's careful and explains what it's doing, but you are trusting it. Use it on your own machine, keep backups of anything precious, and if that trade-off doesn't sit right with you, you can always switch modes with **Shift+Tab** in the Claude input box.

The first time you start a session, Claude Code may show a confirmation asking you to accept bypass-permissions mode — accept it to get the full setup.

---

## Step 4 — Paste the magic prompt

This is where Claude takes over and does what would otherwise be twenty fiddly steps.

1. Open VS Code and start a new Claude Code chat.
2. Open `BOOTSTRAP-PROMPT.txt` (in Notepad is fine), select all of it, and copy.
3. Paste it into the Claude chat and press Enter.

Claude will then, on its own: fix the configuration paths for your username, install a few free helper tools (Node.js, Python, jq), connect the plugin libraries, install the memory system, Superpowers, and the gstack skills engine, create your fresh knowledge vault, and verify every part works. It narrates as it goes.

**This takes 15–30 minutes.** It will pause to ask you for the API keys from Step 5 — you can give them to it, or say "skip the council for now" and add them later.

When it finishes, it prints a checklist of what's working. **Close VS Code and reopen it** so everything loads fresh.

---

## Step 5 — Free API keys for second opinions (optional but recommended)

The `/ask` council needs its own keys to talk to other AI companies. Both are free to get:

- **Google Gemini** (free): go to https://aistudio.google.com/app/apikey — sign in with a Google account, click **Create API key**, copy the long code that appears.
- **Kimi / Moonshot** (free trial credit): go to https://platform.moonshot.ai — sign up, find **API Keys** in the console, create one, copy it.

You don't need to put these anywhere yourself — just paste them into the chat when the bootstrap prompt asks. (Treat keys like passwords: don't email them around or reuse Harry's.)

---

## Step 6 — Check it all works

In a fresh session, try these:

- Type anything — the reply should come from **Opus** (bottom of the Claude panel shows the model) and shouldn't ask permission to look at files.
- Type `/status` — checks the council's connections (Gemini/Kimi show ✓ if you added keys).
- Ask *"what do you remember about this project?"* — after a session or two, the memory system will genuinely answer.
- Type `/make-pdf` on any notes file — a good first taste of the skills library.

---

## When something goes wrong

The golden rule of this whole setup: **describe the problem to Claude and let it fix its own installation.** That's how Harry built it in the first place. For example:

- *"I'm seeing hook errors at the start of every session — investigate and fix them."*
- *"The /ask command says no providers available — fix the council setup."*
- *"Check my Claude setup matches the bootstrap checklist and repair anything broken."*

If Claude itself won't start, the fallback is: delete `settings.json` from the `.claude` folder, restart, and re-do Steps 2–4.
