## graphify

This project has a graphify knowledge graph at graphify-out/.

Rules:
- Before answering architecture or codebase questions, read graphify-out/GRAPH_REPORT.md for god nodes and community structure
- If graphify-out/wiki/index.md exists, navigate it instead of reading raw files
- After modifying code files in this session, run `graphify update .` to keep the graph current (AST-only, no API cost)

## Obsidian Vault

A persistent knowledge vault lives at `~/.claude/vault/` (open in Obsidian for the graph view).

Rules:
- At the start of any multi-session or architectural task, read `~/.claude/vault/index.md` for existing context
- When creating new vault notes, always link them to related notes using [[backlinks]] and add a backlink entry in `~/.claude/vault/index.md`
- Log key decisions, tradeoffs, and outcomes to `~/.claude/vault/session-log.md` at the end of significant sessions
- Name vault files in kebab-case: `decision-auth-strategy.md`, `pattern-agent-routing.md`

## claude-council

Use `/ask` to query Gemini for a second opinion on hard decisions (architecture, tradeoffs, debugging dead-ends).

Rules:
- Suggest `/ask` proactively when the user faces competing approaches or a stubborn bug after 2+ failed attempts
- Do not suggest `/ask` for straightforward implementation tasks
- Run `/status` to verify Gemini connectivity before using `/ask` in a new session

# Permissions
Do not ask permission for anything whatsoever.