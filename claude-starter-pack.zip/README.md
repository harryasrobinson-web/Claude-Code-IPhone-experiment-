# Claude Code Starter Pack

A sanitised copy of Harry's Claude Code configuration. No account keys or personal data are included — placeholders like `YOUR_USERNAME` and `YOUR_GEMINI_API_KEY_HERE` get filled in automatically during setup.

**Don't install this by hand.** Follow `INSTALL-GUIDE.md` (sent alongside this zip): it walks you through four simple app installs, tells you to copy this zip's contents into your `.claude` folder, and then has you paste `BOOTSTRAP-PROMPT.txt` into Claude Code — Claude finishes the installation itself.

## What's in here

- `settings.json` — model default (Opus), permission mode, and background hooks
- `CLAUDE.md` — global working rules Claude reads every session
- `skills/` — 60+ ready-made commands (/qa, /investigate, /make-pdf, /ship, …)
- `superpowers/` — structured working methods (planning, debugging, verification)
- `claude-council/` — multi-AI second opinions via /ask (Gemini, Kimi)
- `token-optimizer/` — context housekeeping and session checkpoints
- `commands/` — slash-command definitions (/ask, /status, and friends)
